class Car:   #class : first letter must be capital.

    # __init__ => constructor function also called magic method or dundder(double underscore) method.
    # Method
    def __init__(self, make, colour, model, price, engine, seat=5):  ## parameters--> used in objects
        self.make = make   #  syntax --> <self.attribute name> = <parameter(args, kwargs) in __init__>
        self.colour_coat = colour   # <self.attribute name> is used in call to perform any operation.
        self.model_year = model     # <parameter (args,kwargs) in __init__> is used in object as args or kwargs.
        self.price_detail = price
        self.engine_type = engine
        self.km = 0.0
        self.seats = seat

        self.airbag = "yes" if make.lower() == "tata" else "no"  # using ternary.

    def sell(self):  # instead of "self" v cn put <'any name'> bt while calling attribute v need to call <'any name'>
        if self.make.lower() == "tata":
            self.price_detail -= 12000.0
        print(f"congratulation on the purchase of brand new {self.make}'s {self.colour_coat} car.")
        print(f"please pay {self.price_detail}")

    def service(self):
        if self.km < 500:
            print("no need to service now, u can wait for some more km")
        if self.km > 2000:
            print("second free service needed, engine quality is good")
        if self.km > 6000:
            print("you are exhausted with free services, this would be free service, do you wish to proceed ?")

    def resell_value(self):
        pass



#Object(instances)
nexon = Car(make="Tata", colour="Black", price=90000.0, engine="petrol", model="2020", seat=8)  #can pass keyword args.
i20 = Car("Hundayi", "Grey", "2014", 75000.0, "petrol", 7)  #(positional and default arguments(seat = 7))
nexon_d = Car(make="TATA", colour="Blue", price=95000.0, engine="diesel", model="2020")
altroz = Car("Tata", colour="Black-yellow", price=70000.0, engine="petrol", model="2020")

### way of call
nexon.sell()
i20.sell()
nexon_d.sell()
altroz.sell()
print(nexon.airbag)
print(i20.airbag)


# print(i20.price)
# print(i20.colour)
# print(i20.make)
# print()
# print(nexon.price)
# print(nexon.colour)
# print(nexon.make)



# neta_chi_Fortuner = Car("Toyota", "White")
# hero_chi_Fortuner = Car("Toyota", "Black")
#
# print(nexon.make)
# print(neta_chi_Fortuner.colour)
# print(hero_chi_Fortuner.make)