'''
OS module :- OS stands for operating sysytem.
This exports:
all functions from posix or nt, e.g. unlink, stat, etc.
os.path is either posixpath or ntpath
os.name is either 'posix' or 'nt'
os.curdir is a string representing the current directory (always '.')
os.pardir is a string representing the parent directory (always '..')
os.sep is the (or a most common) pathname separator ('/' or '\')
os.extsep is the extension separator (always '.')
os.altsep is the alternate pathname separator (None or '/')
os.pathsep is the component separator used in $PATH etc
os.linesep is the line separator in text files ('r' or 'n' or 'rn')
os.defpath is the default search path for executables
os.devnull is the file path of the null device ('/dev/null', etc.)
'''

import os

# # cwd :- current working directory.
# cwd = os.getcwd()   ### ans :- C:\Users\LIKESH\PycharmProjects\Pycharm Projects\module_import_execute\OS_module
# print(cwd)
#
# # chdir :- change directory
# os.chdir("C:/Users/LIKESH/PycharmProjects/Pycharm Projects/module_import_execute")
# print(os.getcwd())

#listdir :- list directory
# list_dir = os.listdir("C:/Users/LIKESH/PycharmProjects/Pycharm Projects/Datatypes")
# print(list_dir)

#mkdir :- make directory
# os.mkdir("lik_file")

#makedirs :- to make multiple directories. (use it)
# os.makedirs("test1/test2/test3")

#rmdir :- remove directory (use it)
# os.rmdir("lik_file")

#removedirs :- removes all multiple directories
# os.removedirs("test1/test2/test3")

# rename to file only but directory is empty then only possible
# os.rename("OS_introduction.py","os_intro.py")

#stat :-
# stat = os.stat("os_module.py")
# print(stat)
# print(stat.st_size)

#environ :- environment
# env = os.environ
# print(env)
#
# if "win" in os.environ.get("OS").lower():
#     print("succesfully executed")
# os.chdir(os.environ.get("HOMEPATH"))
# print(os.getcwd())
# os.chdir(os.environ.get("HOMEDRIVE") + os.environ.get("HOMEPATH"))
# print(os.getcwd())

# ##walk
#
# tree = os.walk("C:/Users/LIKESH/PycharmProjects/Pycharm Projects")
# print(tree)
#
# # for item in tree:
# #     print(item)
# file_name = input("enter file name")
# for dir, sub_dirs, file in tree:
#     if file_name.lower() in [f.lower() for f in file]:
#         print(f"file is present{dir}")

##path and path's operation.
# path_join = os.path.join("C:/Users\LIKESH\PycharmProjects\Pycharm Projects","Datatypes")
# print(path_join)

### split
# path_split = os.path.split("C:/Users\LIKESH\PycharmProjects\Pycharm Projects\Datatypes")
# print(path_split)
# print(path_split[-1])
#
# ##isfile
# print(os.path.isfile("C:/Users\LIKESH\PycharmProjects\Pycharm Projects\Datatypes/type_conversion.py"))
# print(os.path.isfile("C:/Users\LIKESH\PycharmProjects\Pycharm Projects\Datatypes"))
#
# ##isdir
# print(os.path.isdir("C:/Users\LIKESH\PycharmProjects\Pycharm Projects\Datatypes/type_conversion.py"))
# print(os.path.isdir("C:/Users\LIKESH\PycharmProjects\Pycharm Projects\Datatypes"))
#
# ##exists
# print(os.path.exists("C:/Users\LIKESH\PycharmProjects\Pycharm Projects\Datatypes"))
# print(os.path.exists("C:/Users\LIKESH\PycharmProjects\Pycharm Projects\Data"))

# print(os.path.basename("C:/Users\LIKESH\PycharmProjects\Pycharm Projects\Datatypes"))
