#
# '''
# List:
# • Backed by Array
# • Index Based - start from 0 - Index can be Positive and Negative - Positive Index >=0, Negative Index <=-(Length)
# • # E.g.: a [-2] is a[length-2]
# • Holds homogeneous + heterogeneous data elements (For Hetro Every element is treated as Object)
# • Mutable - can append/add/replace/remove/update
# • Sequence Order is Preserved
# • Duplicates are Allowed.
# • Multiple None Type Allowed
# • Ideal for searching and retrieval
# • Insertion and Deletion are costly operations
# inbuilt methods: append, insert, extend, copy, count, reverse, sort, pop, remove, clear, index
# '''

# ***********************defining list*****************
# l1 = list()
# l2 = [1, 2, 3 ,4]
# l3 = []
# sample_list = [10, 20, 30, 40,50]
# print(sample_list)
#
sample_list1 = [1, 2, 3, 4, 5, 6, 'messege', "number"]
# print(sample_list1)
# print(type(sample_list1))
# sample_list1.append("charachter")
# print(sample_list1)
# user_list = [ "age", "height", "gender"]
#
types_of_denomination = [1, 2, 5, 10, 20, 50, 100, 200, 500]
# print("type of denomination",types_of_denomination)


# **********************LIST_OPERATIONS************
# a = "list_operations"
# print(a.upper())

# append(item) : add element to end
# append recieves one element at a time

# types_of_denomination.append([ "gpay", "paytm", "amazonpay", "phonepay"])
# print( "after append", types_of_denomination)

# extend = extend the list with new list, merge thr element

# digi_currency = [ "gpay", "paytm", "amazonpay", "phonepay"]
# types_of_denomination.extend(digi_currency)
# print("extended list", types_of_denomination)
#
# list1 = ("extended list", types_of_denomination)
# types_of_denomination[5] = 5500 # addition of element in list
# print(types_of_denomination)

# length of list
# print("lentgh of types_of_denomination", len(types_of_denomination))

#count

# print(types_of_denomination.count(5))

# indexing........

# print("element at index 2 = ", types_of_denomination[2])
# print("element at index -13 =", types_of_denomination[-13])
# print("element at index 13 = ", types_of_denomination[13])
# print("element at index 9 = ", types_of_denomination[9])
# print("element at index -2 =", types_of_denomination[-2])
# # index(element)
# print( "elements index =", types_of_denomination.index("phonepay"))
# # insert(index, element) :- insert the element at given index
# types_of_denomination.insert(3,5000)
# print(types_of_denomination)

# reverse() :- reverse the list

# types_of_denomination.reverse()
# print(types_of_denomination)
# # again reverse
# types_of_denomination.reverse()
# print(types_of_denomination)

# pop : remove last element of list

# poped_list = types_of_denomination.pop()
# print(types_of_denomination)
# print(poped_list)

# poped_list = types_of_denomination.pop()
# print(types_of_denomination)
# print(poped_list)
#
# poped_list = types_of_denomination.pop()
# print(types_of_denomination)
# print(poped_list)

# remove(element)
# types_of_denomination.remove(200)
# print(types_of_denomination)
# types_of_denomination.remove(5500)
# print(types_of_denomination)


# to remove the element by index
# index = 3
# types_of_denomination.remove(types_of_denomination[index])
# print(types_of_denomination)

# copy
# list_of_denomination = types_of_denomination.copy()
# print("copy")
# print("copied_list",list_of_denomination)
# print("original_list",types_of_denomination)
#
# list_of_denomination.append("2500")
# print(list_of_denomination)


# sort() the list
# same type of data
# print("sort")
# l1 = ["01","46","41","04","21","03","56","19"] # ["1","46","41","4","21","32","56","19"] #doubt
# print(type(l1))
# l1.sort()
# print(l1)
# l1.sort(reverse=True)
# print(l1)
## trick
# l11 = [1, 5, 3, 7, 5, 9]
# xx = l11.sort(reverse=True)
# print(l11)  # sort() function makes permanent changes.
# print(xx)  # it returns None
#
# yy = sorted(l11)  # sorted function retain original list.
# print(yy)

# clear
# print('clear')
# l1.clear()
# print(l1)
# l1.append("31")
# print(l1)

### methods to add multiple lists.
# l1 = ["01","46","41","04","21","03","56","19"]
# l2 = [1, 2, 5, 10, 20, 50, 100, 200, 500]
# l3 = l1 + l2
# print(l3)

l1 = ["01", "46", "41", "04", "21", "03", "56", "19"]
l2 = [1, 2, 5, 10, 20, 50, 100, 200, 500]
l1.extend(l2)  # ans:-['01', '46', '41', '04', '21', '03', '56', '19', 1, 2, 5, 10, 20, 50, 100, 200, 500]
# print(l1)


# l1.append(l2)  #ans:-['01', '46', '41', '04', '21', '03', '56', '19', [1, 2, 5, 10, 20, 50, 100, 200, 500]]
# print(l1)
# l1.insert(4, l2)  #ans :- ['01', '46', '41', '04', [1, 2, 5, 10, 20, 50, 100, 200, 500], '21', '03', '56', '19']
# print(l1)
