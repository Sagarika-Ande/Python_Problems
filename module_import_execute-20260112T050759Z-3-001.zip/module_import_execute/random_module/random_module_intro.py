import random
### random
x = random.random()
# print(x)

### randrange
y = random.randrange(0, 21, 2)
# print(y)

### randint
int_random = random.randint(1, 10)
# print(int_random)

discount = 500*int_random/100
# print(discount, "%")

### choice
names = ["pawan", "sohan", "mohan", "rohan", "bhuvan"]
title_name = ["singh", "sharma", "verma", "ahuja"]
domain = ["gmail.com", "hotmail.com", "yahoomail.com"]

name_choices = random.choice(names)
# print(name_choices)

# for _ in range(1,101):
    # print(f"{random.choice(names)}.{random.choice(title_name)}@{random.choice(domain)}")

### shuffle
cards = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 1, 2, 3,
         4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
random.shuffle(cards)  # it shuffles  <variable data> and again stored in <variable>(ie cards)
# print(cards)

captcha_codes = ["d", "2", "@", "f", "8", "o", "$"]
random.shuffle(captcha_codes)
# print("".join(captcha_codes).upper())

### choices
print(random.choices(cards, k=3))   # k= number of items
print(random.choices(cards, k=13))
print(random.choices(captcha_codes, k=3))
print(random.choices("".join(captcha_codes).upper(), k=4))

