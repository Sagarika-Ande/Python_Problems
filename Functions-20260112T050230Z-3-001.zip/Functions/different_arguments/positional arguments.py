def get_values(age,height,weight,gender,allergy):
    print("age =",age)
    print("height =",height)
    print("weight =",weight)
    print("gender =",gender)
    print("allergy =",allergy)
get_values(25,5.8,62,"M","sinus") # positional arguments
print()
# get_values(5.8,25,"sinus",62,"F") #disadvantage....user need to defined appropriate parameter.

#rules of arguments
#get_values(25,5.8,62,"M","sugar")  # error missing 1 required positional argument
#get_values(25,5.8,62,"M","sinus","covid") # error take 5 positional arguments but 6 were given
