# Type conversion/casting:
# Converting value of one datatype to another datatype is called type conversion or type casting.
# There 2 type of type conversion in python.
# • Implicit Type Conversion
#  • Explicit Type Conversion
# Implicit Type Conversion:
# Python automatically converts one data type to another. We don’t need to involve here.
# Python avoids loss of data in implicit type conversion
# Explicit Type Conversion:
# In this type conversion programmer converts the datatype of object from one to another, by using function
# like int (), float () str (), list (), tuple (), set ().
# This is also called type casting as programmer casts the datatype of objects.
# Data loss may happen as programmer enforces the conversion

# IMPLICIT TYPE CONVERSION
# num = 4 + 5.5  # int = 4 and float = 5.5
# print(num)
# print(type(num))

######## EXPLICIT TYPE CONVERSION (data loss may be occurred)
#### number(int,float,complex) to other datatypes.
# num = 57
# avg = 78.23
#
# int_num = int(num)
# print(int_num)
#
# float_num = float(num)
# print(float_num)
#
# str_num = str(num)
# print(str_num)
#
# str_avg = str(avg)
# print(str_avg)
#
# list_num = [num]
# print(list_num)
# print(type(list_num))
#
# #tuple not perform
#
# set_num = {num}
# print(set_num)
# print(type(set_num))
#
# dict_num = {num: "none"}
# print(dict_num)
# print(type(dict_num))

#### string to other datatypes

# mob_string = "9856475218"
# print(mob_string)
# print(type(mob_string))
#
# int_mob = int(mob_string)
# print(int_mob)
# print(type(int_mob))
#
# float_mob = float(mob_string)
# print(float_mob)
# print(type(float_mob))
#
# list_mob = list(mob_string)
# print(list_mob)
# print(type(list_mob))
#
# tuple_mob = tuple(mob_string)
# print(tuple_mob)
# print(type(tuple_mob))
#
# set_mob = set(mob_string)
# print(set_mob) # duplicates are not allowed
# print(type(set_mob))

# dict_mob = dict.fromkeys(mob_string, "user")
# print(dict_mob)
# print(type(dict_mob))
# print(dict_mob.values())
# print(dict_mob.keys())

### list to other types of data

# list1 = ["a", "ed", "12", "13", "134", "ghas"]
# print(list1)
# print(type(list1))

# print("".join(list1))
#
# str_list = str(list1)
# print(str_list)
# print(type(str_list))

# set_list = set(list1)
# print(set_list)
#
# tuple_list = tuple(list1)
# print(tuple_list)
#
# dict_list = dict().fromkeys(list1,"user")
# print(dict_list)
# print(dict_list.values())
# print(dict_list.keys())


#### set to other datatypes

# set1 = {"10", "29", "3", "ed", "f3", "ghh"}
# print(set1)
# print("".join(set1))
# str_set = str(set1)
# print(str_set)
#
# list_set = list(set1)
# print(list_set)
#
# tuple_set = tuple(set1)
# print(tuple_set)
#
# dict_set = dict().fromkeys(set1, "typo")
# print(dict_set)
# print(dict_set.keys())
# print(dict_set.values())

##### tuple to other data types

# tuple1 = ("2", "34", "5er", "ty")
# print(tuple1)
# print("".join(tuple1))
# str_tup = str(tuple1)
# print(str_tup)
#
# list_tup = list(tuple1)
# print(list_tup)
#
# set_tup = set(tuple1)
# print(set_tup)
#
# dict_tup = dict().fromkeys(tuple1, "goods")
# print(dict_tup)
# print(dict_tup.values())
# print(dict_tup.keys())

##### dictionary to other datatypes

dict1 = {"color": "orange", "country": "india", "food": "indian", "fruit": "orange"}
print(dict1)

print("".join(dict1))  # only keys get operated

str_dict = str(dict1)  # only keys get operated
print(str_dict)

list_dict = list(dict1)  # only keys get operated
print(list_dict)

set_dict = set(dict1)  # only keys get operated
print(set_dict)

tup_dict = tuple(dict1)  # only keys get operated
print(tup_dict)

### item, keys, value of dictionary

print(dict1.items())
print(dict1.keys())
print(dict1.values())

## items iteration

#print("".join(dict1.items()))  # item can not perform operation

str_itm = str(dict1.items())
print(str_itm)

list_itm = list(dict1.items())
print(list_itm)

set_itm = set(dict1.items())
print(set_itm)

tup_itm = tuple(dict1.items())
print(tup_itm)

## keys iteration

print("".join(dict1.keys()))

str_keys = str(dict1.keys())
print(str_keys)

list_keys = list(dict1.keys())
print(list_keys)

set_keys = set(dict1.keys())
print(set_keys)

tup_keys = tuple(dict1.keys())
print(tup_keys)

## values iteration

print("".join(dict1.values()))

str_val = str(dict1.values())
print(str_val)

list_val = list(dict1.values())
print(list_val)

set_val = set(dict1.values())
print(set_val)

tup_val = tuple(dict1.values())
print(tup_val)



