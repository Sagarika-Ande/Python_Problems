
# ## methods of importing module , files etc
# import os
# import math
# import sys
# import datetime
# import json as js   # tuple and set are not executed
#
# # from Datatypes import set_introduction
# # from Functions.different_arguments import arbitrary_argument_function
#
# import datetime as dt
# from datetime import datetime as dt
#
# data = {"name":"first"}  # this is dict but API communication we transfer json data instead of dict.
# print(js.dumps(data))
#
# data1 ='{"data":"first"}' # data (this is string) not dict. if we need to convert it into dict then
# print(js.loads(data1))   ## in json {':'} must be there.
#
# print(sys.path)
# print(os.path)

# module ,library and package
# collection of repeated codes is called function.
# collection of various different function is called module.
# collection of different module is called library.
# collection of different library is called package.

# there are 1) standard module :- which is already installed in IDE of python.
#           2) non-standard module :- which is not installed but need to install from internet using in python

