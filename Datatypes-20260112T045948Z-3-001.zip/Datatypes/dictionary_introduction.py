#
# '''
# Dictionary:
# • Internally implemented as hash table and uses closed hashing a.k.a open addressing
# • Unlike other data types Dictionary holds a pair (KEY, VALUE) as a single element.
# • Dictionary is mutable4xxv v4423    3e
# • Key must be immutable (String, Number, Tuple) and no duplicates allowed.
# • Value can be of any type (Mutable or immutable) and duplicated are allowed.
# • elements are accessed using keys
# • can be nested
# • insertion deletion is efficient and searching is not efficient compared to insertion/deletion.
# Dict_methods:
# copy (), clear (), fromkeys (), get (), items (), keys (), values (), pop (), popitem(), setdefault(), update()
# how to use/create:
# new_dict = {}
# new_dict= {key1:value1, key2:value2, key3:value3, ...., key_n: value_n}
# new_dict = dict () / This will create a blank dictionary.
# # new_dict = dict ({key1:value1, key2:value2, key3:value3, ...., key_n: value_n})
# # eg:
# # data = {'action': 'list', 'state': 'Finished', 'show_last': 1, 'target': ip}
# # my_preference = dict ({'fruit': 'pomegrante', 'bike': 'honda', 'cuisine': 'chinese', 'weather': 'winter'})
# # '''
#
# # dict_1= {key1:value1, key2:value2, key3:value3, key_n: value_n}
# # print(type(dict_1))
# # print(dict_1)
# empty_dict_2 = dict ()
# print(type(empty_dict_2 ))
# print(empty_dict_2)
# # dict2 = dict ({key1:value1, key2:value2, key3:value3, key_n: value_n})
# # print(type(dict2))
# # print(dict2)
#
#
# dictionary_define = {"fruit": "orange", "country": "india", "colour": "orange", "food" :["south","north"]}
# print(type(dictionary_define))  # keys are immutable and values are mutable
# print(dictionary_define)
#
# indian_team ={ "captain":"kohli", "vc": "rahul", "batsman": ['rahul','pujara', 'rahane'], "wk": "pant",
#                "bowlers": {"spin": ["ashvin", "jadeja"], "fast":['bumrah','shami']},"coach": "rahul"}
# print(type(indian_team))
# print(indian_team)
#
# # reading dictionary
# print("reading_dictionary")
# print(dictionary_define["food"])
# print(indian_team["captain"])
# print(indian_team["bowlers"])
#
# #.get(key, <default_value>)
#
# print(indian_team["coach"])
# # print(indian_team["physio"])  # it gives error
#
# print(indian_team.get("coach","ravi"))
# print(indian_team.get("bowlers"))
#
# print(indian_team.get("physio","ramesh")) # it return none or given name ex ramesh
# print(indian_team["bowlers"]["fast"][0])
# (indian_team["batsman"].append("mayank"))  #list is append
# print(indian_team)
# # print(indian_team["captain"].append("mayank"))  #captain is str. it cannt append
#
# # items, keys,values
#
# print( "dict_items=",indian_team.items()) # it gives in tuple format(tuple use for multiple data store)
# print("dict_keys=",indian_team.keys())
# print("dict_value=",indian_team.values())
# print(indian_team["bowlers"].keys()) # to access inner keys, need to mentioned
# print(indian_team["bowlers"].values()) # to access value keys, need to mentioned
# print(indian_team["bowlers"]["spin"][1]) # to access inner keys, need to mentioned
#
# # for loop in dictionary
# #
# # for keys,value in indian_team.items():
# #     print(f"{keys}--------{value}")
#
# # dict_update
#
# u19_team ={"u19th": {"captain":"dhul", "vc": "amd"}}
# med = {"med": {"shardul","hardik"}}
# print("update")
# print("before",indian_team)
# indian_team.update({"12th man":"saha"})
# indian_team.update(u19_team)
# indian_team["bowlers"].update(med)
# print("after",indian_team)
#
# #setdefault
#
# def_data =indian_team.setdefault("captain", "ganguly") # if key is present returns default value
# print("1 condition", def_data)
# def_data2 =indian_team.setdefault("sponser", "tata") #if key is not present returns given value
# print("2 condition",def_data2)
# print(indian_team)
# print(indian_team["sponser"])
#
#
# #dict().fromkeys

my_dict = {"colour","food","city"}
print(type(my_dict))
new_data = dict().fromkeys(my_dict)
print("final_data",new_data)

##### methods to add multiple dictioneries
# dict1 = {"colour": "orange","food": "indian","city": "nagpur"}
# dict2 = {1:"piyush",2:"likesh"}
# dict3 = {**dict1,**dict2}
# print(dict3)

# dict1 = {"colour": "orange","food": "indian","city": "nagpur"}
# dict2 = {1:"piyush",2:"likesh"}
# dict1.update(dict2)
# print(dict1)