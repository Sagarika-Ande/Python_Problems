
#
# In Python,we have the following types of loop:
# • for loop
# • while loop
# • expanded for loop
# • for else loop
# • while else loop
# pass, break, continue.
# integer and float are not iterable in loop.


str = "namashkar"
l = [1, 2, 3, 4, 5, 6, 7, 8]
t = (11, 22, 33, 44, 55)
dict = { "num1": 21, "num2": 22, "num3": 23, "num4": 24}
set1 = {101, 102, 103, 104, 105, 106}
# l = list(range(1,151))

########for loop:-  apply on data

# for given_variable in l:

#     if given_variable % 2 == 0:
#         print(f"{given_variable} is even")
#         print("**")
#     else:
#         print(f"{given_variable} is odd")
#         print("***")
#     print("@")
#     # print(given_variable+10)
#     # print(given_variable*10)
#     # print(given_variable/10)
#     # print(given_variable//2)
#     # print(given_variable % 2)
#     # print(given_variable**2)
#     # print()

# for loops on different types of data
# print("for string")
# for item in str.upper():
#     print(item)

# print("for list")
# for item in l:
#     print(item)

# print("for tuple")
# for item in t:
#     print(item)

# print("for dict")
# for _ in dict:
#     print(list(dict.keys()))
#     print(list(dict.values()))
#     print(list(dict.items()))
#     print()
#     break

# print("for set")
# for item in set1:
#     print(item)

####### while loop :- apply on "condition". we need to give "increment" every time to perform iteration.

# i = 0    # condition
# while i < 10:
#     i += 1   # increment
#     print("* "*i)

#### factorial of numbers
# num = 12345
# fact = 1
#
# while num > 0:
#     fact *= num % 10
#     num = num//10
# print(fact)

#### addition of digits of numbers
# num = 54633
# sum = 0
#
# while num > 0:
#     sum = sum + num % 10 # sum+=num % 10
#     num = num//10    # num //= 10
# print(sum)

###########expanded for loop
# print(dict.items())
# for keys,values in dict.items():
#     print(f"{keys} and {values}")

# std1 = [67,78,56]
# std2 = [86,59,79]
# std3 = [98,97,92]
# for sub1,sub2,sub3 in zip(std1,std2,std3):
#     print(f"marks of student 1 {sub1}")
#     print(f"marks of student 2 {sub2}")
#     print(f"marks of student 3 {sub3}")

# for index,item in enumerate (t,0):
#     print("index",index)
#     print("item of tuple",item)

##### for else loop
##### while else loop

# l = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
#
# for item in l:
#     if item % 5 == 0:
#         break
#     print(item)
#
# else:
#     print("loop exit successfully")


num=32
for i in range(2, num):
    if num % i == 0:
        print("number is not prime")
        break
else:
    print("number is prime")


# how to mentions variable name in loop

sizes = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096]
currency = [1, 2, 5, 10, 20, 50, 100, 200, 500]
months = ["jan", "feb", "march", "april", "may", "june"]
weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']

for size in sizes:
    pass
for note in currency:
    pass
for month in months:
    pass
for day in weekdays:
    pass