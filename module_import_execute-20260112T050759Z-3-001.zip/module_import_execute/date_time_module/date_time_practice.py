from datetime import date
from datetime import time
from datetime import datetime


# print(date.today())
# print(date.today().weekday())
# print(time.min)
# print(time.max)
# today = date.today()
# print(today)
# print(today.strftime("%Y:%m:%d"))
# print()
#
# # time
# tt = time(11, 45, 10)
# print(tt.strftime("%H:%M:%S"))
# print()

# ### timedelta
# from datetime import datetime, timedelta
# current_dt = datetime.now()
# back_dt = datetime(2019, 10, 19, 4, 30, 45)
# dt_delt = current_dt - back_dt
# print(type(dt_delt))
# delt_5 = timedelta(seconds=5)
#
# while True:
#     if datetime.now() - current_dt > delt_5: # datetime.now is incremental but current_dt is static.
#         break
#
#     print("****")


### sleep
import time
# print("$$$$")
# time.sleep(4)
# print("***")


t1 = time.time()
time.sleep(6)
t2 = time.time()
print(f"show execution delay = {(t2-t1)- 6}")