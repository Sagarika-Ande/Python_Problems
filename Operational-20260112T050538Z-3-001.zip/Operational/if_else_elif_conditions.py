
#
# if True:  # if, else, elif are conditions statements. not loop
#     print("11")
#     print("22")
#     print("31")
#     print("45")
# print("6")
#
# if False:
#     print("false")
#     print("10")
#     print("12")
# print("50")
#
# # if else ( if and else comes with each other without space).
#
# if True:
#     print("11")
# else:
#     print("22")

# if False:
#     print("33")
# else:
#     print("44")

# input function :- input function is used to take input("string") from console or user.
# input("string") can convert to integer or float by using int or float. ex num_in = int(input("enter number")).
# input, print etc. function cannot use while submitting final main projects.

# program of odd and even using if else condition.
# num = int(input("enter the number"))
# if num % 2 == 0:
#     print("even")
# else:
#     print("odd")

# endswith
# if "monday".endswith("day"):  # here monday is "string" and day is "substring".
#     print("yes")
# else:
#     print("no")

# to chk class of student.
# avg = float(input("enter average = "))
#
# if avg >= 90:
#     print("toppers")
# elif avg >= 75:
#     print("distinction")
# elif avg >= 60:
#     print("first class")
# elif avg >= 50:
#     print('second class')
# elif avg >= 40:
#     print(" just pass")
# else:
#     print("fail")

# day = input("enter the day").lower()
# if day.startswith("mon"):
#     print("first day of week")
# elif day.startswith("tue"):
#     print("second day of week")
# elif day.startswith("wed"):
#     print("third day of week")
# elif day.startswith("thurs"):
#     print("fourth day of week")
# elif day.startswith("fri"):
#     print("fifth day of week")
# elif day.startswith("sat"):
#     print("sixth day of week")
# elif day.startswith("sun"):
#     print("seventh day of week")
# else:
#     print("given day is not valid day")

emails = {"lik@gmail.com": "123", "nil@gmail.com": "567"}
email = input("enter email")
if email in emails:
    # print("email is registered")
    password = input("enter password")
    if password == emails[email]:      #doubt clear [] because its [{keys:value}==dict
        # print(emails[email])
        print("succesful login")
    else:
        print("wrong password")
else:
    print("email is not registered")
