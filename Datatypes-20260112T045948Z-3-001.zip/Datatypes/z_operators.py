
#
# Python divides the operators in the following groups:
#
# Arithmetic operators
# Assignment operators
# Comparison operators
# Logical operators
# Identity operators
# Membership operators
# Bitwise operators

print("https://www.w3schools.com/python/python_operators.asp")

# Operator	              Name	                     Example
# +	                    Addition	                   x + y
# -	                    Subtraction	                    x - y
# *	                    Multiplication	                x * y
# /	                    Division	                    x / y
# %	                    Modulus	                        x % y	reminder
# **	                Exponentiation	                x ** y	ex 2**4 =2*2*2*2
# //	                Floor division	                x // y   ex 15//2 = 7 or 14//2 =7 or 13//2 =6 or 12//2 =6


### floor division
print(-2.2//2)  # floor division for (-) dividend will be next int value of quotient.
print(3.5//2)   # floor division for (+) dividend will be previous int value of quotient.