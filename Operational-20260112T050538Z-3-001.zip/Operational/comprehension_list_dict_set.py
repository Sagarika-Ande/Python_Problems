# comprehension :- short hand way of creating list, sets and dict
# single condition at a time  with if condition
# list comprehension:-
# syntax:- [<variable_name>for<same_variable_name>in condition(iteration)

##using comprehension
# number_list = [num for num in range(1, 101)]
# even_list = [num for num in range(1, 101) if num % 2 == 0]
# print(number_list)
# print(even_list)

# using python way
# list100 = list(range(1, 100))
# print(list100)
#
# even_list =[]
# for num in range(1,101):
#     if num % 2 == 0:
#         even_list.append(num)
# print(even_list)

## set comprehension
# set_compr = {item for item in range(1, 101)}
# print(set_compr)

# dictionary comprehension

##dict_compr = {key: value for key,valaue in enumerate( even_list, 0)}

ascii_dict = {key: ord(str(key)) for key in range(1, 10)}  # ord stands for ordenance and execute for ascii number
print(ascii_dict)
