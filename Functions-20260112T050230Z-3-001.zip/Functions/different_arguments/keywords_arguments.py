def get_values(age,height,weight,gender,allergy):
    print("age =",age)
    print("height =",height)
    print("weight =",weight)
    print("gender =",gender)
    print("allergy =",allergy)
# get_values(age=32,height=5.8,gender="M",weight=59,allergy="sugar")
print()
get_values(height=5.6,age=34,weight=51,allergy="apendx",gender="M")

#get_values(age=34,weight=51,allergy="apendx",gender="M") # missing 1 required positional argument: 'height'

#get_values(32,56,height=5.8,gender="M",allergy="sugar") #got multiple values for argument 'height'
