
# '''
# Tuple:
# • Very Similar to lists
# • Index Based Operations Allowed
# • Holds homogeneous + heterogeneous data elements (For Hetro Every element is treated as Object)
# • Immutable Cannot be Changed
# • Sequence Order is Preserved
# • Duplicates are Allowed
# • Multiple None Type Allowed
# inbuilt methods: count, index
# imp...exception addition of two tuple...
# how to use:
# reference_name = (val1, val2, val3, val4)
# reference_name = tuple([val1, val2, val3])
# Eg:
# weekdays = ('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')
# vowels = tuple([‘a’ ,’e’, ‘i’, ‘o’, ‘u’])
# Nesting tuples is possible.
# tuple r faster than list..and consume less memory.
# '''
#

months = ("jan", "feb", "march", "april", "may", "june")
vowel = ("a", "e", "i", "o", "u")

print(type(months))
print(type(vowel))

print(months[-2])
print(vowel[1])

print(months.count("march"))
print(months.index("june"))

# exception of tupple

t1 = ("2", "4", "6", "8")
t2 = ("10", "12", "14")
addition_of_tupple = t1 + t2
print(addition_of_tupple)