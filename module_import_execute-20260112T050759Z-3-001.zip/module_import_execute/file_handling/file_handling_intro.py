# team_india = open("india_team")
# print(team_india.read())
# team_india.close()
##### read file
# ### file handling by context manager :- no need to give close
# with open("india_team") as team_india:   # syntax of open(file,mode)....here default mode is read(r)..
#     print(team_india.readline().upper())  #readline reads lines form top of file line by line.
#     print(team_india.readline())
#     print(team_india.readline())
#     print("..............#######...............")
#
#     lines = team_india.readlines()  #readlines:- it convertd data to list hence v can perform any opertion of list.
#     print(lines)
#     print((lines))
#     # for line in lines:
#     #     print(line)
#     print(team_india.read())

### write file
## wf = open("test_team.txt","w")
# with open("test_team.txt", "w") as wf:    # new txt file will create and we can write anything here.
#     wf.write("hi, this is likesh \n how was ur day? \n what day today? \n hav a nice day. ")

# with open("india_team") as rf:
#     with open("test_team.txt", "w") as wf:
#             # wf.write(rf.read())
#         wf.write(rf.readline())
#         wf.write(rf.readline())
#         wf.write(".......#####......\n")
#         wf.writelines(rf.readlines())
#         # for line in rf.readlines():
#         #     wf.write(line.upper())
#         wf.write("\n\nhell python\ngood to see u\nhav a nice day guys")


# with open("india_team") as rf:
#     with open("test_team11.txt", "w") as wf:
#             # wf.write(rf.read())
#         wf.write(rf.readline())
#         # wf.write(rf.readline())
#         # wf.write(".......#####......\n")
#         # wf.writelines(rf.readlines())
#         for line in rf.readlines():
#             wf.write(line.upper())
#         wf.write("\n\nhell python\ngood to see u\nhav a nice day guys")


# #### append write data ata last of file
#
# with open("test_team11.txt", "a") as af:
#
#     af.write("\n\nhello python\ngood to see u\nhav a nice day guys")

# with open("p.jpg","rb") as rf:
#     with open("pw.jpg","wb") as wf:
#         wf.write(rf.read())