
# with open("p.jpg","rb") as rf:
#     with open("pw.jpg","wb") as wf:
#         wf.write(rf.read())

##### seek   w+ = write +read   also 'seek' need to use.
# with open("new_seek.txt", "w+") as wf:
#     wf.write("first line\n")
#     wf.write("second line\n")
#     wf.write("third line\n")
#     print(".........")
#     wf.seek(0)
#     print(wf.read())
#     wf.write("fourth line\n")

#####  r+ = read + write
# with open("new_seek.txt", "r+") as rf:
#     # wf.write("first line\n")
#     # wf.write("second line\n")
#     # wf.write("third line\n")
#     # print(".........")
#     # wf.seek(0)
#     print(rf.read())
#     rf.write("fifth line\n")

# with open("seekdemo.txt", "r+") as f:
#     f.seek(0, 2)
#     f.write("The concept of file handling is used to preserve the data or information generated after running the program. \nLike other programming languages like C, C++, Java, Python also support file handling.\n")
#     f.seek(0)
#     print(f.read())
