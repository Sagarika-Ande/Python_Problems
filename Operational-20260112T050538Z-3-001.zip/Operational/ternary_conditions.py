# ternary conditions(access with if-else condition)

# using if-else condition
if 10 % 2 == 0:
    print("even")
else:
    print("odd")

# using ternary condition
print("even") if 10 % 2 == 0 else print("odd")

# ###example
# def function1():
#     print(sizes[slice_data])
#     print(currency[slice_data])
#     print(months[slice_data])
#     print(weekdays[slice_data])
# def function2():
#     print(sizes1[slice_data])
#     print(currency1[slice_data])
#     print(months1[slice_data])
#     print(weekdays1[slice_data])
#
# def function1() if % 2 == 0 else def function2()

#### example (one line ternary)
n = 8
(print("number is even and less than equal to 10") if n <= 10 else print("number is even and greater than  10")) if n % 2 == 0 else (print("number is odd and greater than 10") if n > 10 else print("number is odd and less than 10"))



