#
# '''
# Sets:
# • Backed by Hash table - Open address a.k.a closed hashing
# • No Index Based Operations Allowed
# • Holds homogeneous + heterogeneous data elements (For Hetro Every element is treated as Object)
# • sets are Mutable - can add/remove/update
# • but the elements of set should be immutable
# • Sequence Order is Not Preserved
# • Duplicates are not Allowed
# • Single None Type Allowed
# • Ideal for Insertion and Deletion
# • Searching and retrieval might be costly operations
# Set methods: add, clear, copy, difference, difference_update, discard, intersection, intersection_update,
# isdisjoint, issubset, issuperset, pop, remove, symmetric_difference, symmetric_difference_update, unioun, update.
# How to use/Declare:
# new_set = {immutablelement1, immutablelet2, immenmutablelement3}
# new_set = set ([ immutablelement1, immutablelement2, immutablelement3])
# blank_Set = set()
# Note: We cannot use {} to declare as it is already used for dict, hence only set() can be used to declare blank set.
# eg:
# set1 = {1, 3, 2, 4, 8, 9, 0}
# set2 = set ([1, 3, 7, 5, 4, 0, 7, 5])
# '''
# defining set.....
# set_1 = { immutablelement1, immutablelet2, immenmutablelement3}
# set_2 = set ([ immutablelement1, immutablelement2, immutablelement3])
# empty_Set = set()

set1 = {1, 2, 3, 4, 4, 5, 6, 6}   # Duplicates are not Allowed
set2 = set([2, 3, 4, 5, 6, 3, 4])
print(type(set1))
print(type(set2))
print("s1 =", set1)
print("s2 = ", set2)

# add(element):- add an elements to sets( single element at a time)
print("add")
set1.add(7)
set1.add(2)
set2.add(9)
print("s1",set1)
print("s2",set2)

# remove:- remove element from set
print("remove")
set1.remove(3)
print("s1 =", set1)

# discard :discard the given element from set
print("discard")
set1.discard(5)
print(set1)

# pop :- remove random element from set
print("pop")
d = set1.pop()
print("s1 =", set1)
print(d)

a = set2.pop()
print("s2 =", set2)
print(a)

# # clear
# print("clear")
# set1.clear()
# print("s1 =", set1)

# union :- to union two sets
print("union")
union_set = set1.union(set2)
print("s3 =",union_set)

# intersection:- return the intersection of sets
print("intersection")
intersection_set =set1.intersection(set2)
print(intersection_set)

# difference:- a-b and b-a
print("difference")
diffab =set1.difference(set2)
print("a-b =",diffab)
diffba =set2.difference(set1)
print("b-a =",diffba)

# symetric difference
sym_diff =set1.symmetric_difference(set2)
print("sym diff", sym_diff)

# issubset(set) :return true if called set is subset of passed set
# issuperset(set) :return true if called set is superset of passed set
print(set1)
st1_sub1 = {4, 5, 6}
print(st1_sub1.issubset(set1))


st1_sup1 = {2, 4, 5, 6, 7}   #doubt
print(st1_sub1.issuperset(set1))

# disjoint


##len
a = {"s","ddd","dddd"}
aa = {"sd","ddds","ddgdd","ddd","dddd"}

print(len(a & aa))  #ans = 2...it shows common value in sets
