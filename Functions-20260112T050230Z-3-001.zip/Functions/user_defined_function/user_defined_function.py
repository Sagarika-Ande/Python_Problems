'''
User Defined functions:
These functions are defined by user to carry out a particular operation.
We can edit and use them whenever required
User can define function in following ways:
Non parameterized function and returns None:-
def function_name():
code block
Parameterized function and return None:
def function_name(parameter1, parameter2, parameter3,…,parameter):
Non parameterized function but returns some value:
def function_name():
code block performs some operation
returns some value using return keyword
return 10*20
Parameterized function and returns some value:
def function_name(parameter1, parameter2, parameter3,…,parameter):
code block
return parameter1+parameter2+parameter3
Calling the function
• Function will only execute when it is called. In order to call function, we use function name with round braces
• While calling the function we have to pass all required parameter as per the function definition.
function_name()
function_name(1,2,3,4…,n)
'''

# #syntax
# def function_name():
#     line1
#     line2
#     line3
#     return True
# #calling function
# function_name()
#
########### def non_parameteriezed_function_and_return_non():
#     pass
#
# print("news")
# def non_parameterized_function_odd_even():
#     print("first line")
#     print("second line")
#     if 13%2 == 0:
#         print("odd")
#     else:
#         print("even")
#     print("second last line")
#     print("last line")
# print("new news")
# non_parameterized_function_odd_even()#it is very important to call function for execution.can call for many times.
# print()
# function_define_odd_even()

########### def non_parameteriezed_function_and_return_something():
#
# print("test")
# print("debug")
# def odd_even():
#     if 44 % 2 == 0:
#         return True
#     else:
#         return False
# odd_even()
# print(odd_even())
#
# if odd_even():
#     print("even")
#
# result = odd_even()
# if result:
#     print("even")
# else:
#     print("odd")

########### def parameteriezed_function_and_return_non():

# def odd_even(num):
#     if num % 2 == 0:
#         print("even")
#     else:
#         print("odd")
# print(odd_even(54))
# print(odd_even(47))
# print(odd_even(65))
# print(odd_even(5646))
# print(odd_even(3249))

########### def parameteriezed_function_and_return_something():
# print("")
# print("")
#
#
# def odd_even(num):
#     if num % 2 == 0:
#         return True
#     else:
#         return False
# print(odd_even(79))
# print(odd_even(5554))
# print(odd_even(46+5))
# print(odd_even(56))
# print(odd_even(22))


def chk_class(avg):
    if avg >= 90:
        print("toppers")
    elif avg>= 75 :
        print("distinction")
    elif avg>= 60:
        print("first class")
    elif avg>= 50:
        print('second class')
    elif avg >= 40:
        print(" just pass")
    else:
        print("fail")
# print(chk_class(94))
# print(chk_class(55))
# print(chk_class(79))
# print(chk_class(39))
# print(chk_class(65))

def prime_number(num):
    for i in range(2,num):
        if num % i == 0:
            return True
        else:
            return False
# print(prime_number(49))
# print(prime_number(48))

## what is global variable and local variable.