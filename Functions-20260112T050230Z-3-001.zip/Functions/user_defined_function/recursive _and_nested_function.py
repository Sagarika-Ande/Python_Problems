
def outer_function():  #nested function :-application in decoraters.
    print("entry to inner function")

    def inner_function():
        print("enter number")

    inner_function()

    print("exit to inner function")
# outer_function()

# recursive function:-the process of defining something in terms of itself.the function which calls itself.
# simple method factorial

def factorial(n):
    fact = 1
    for i in range(1, n+1):
        fact = fact * i
    return fact
# print(factorial(5))


def fact(n):
    if n == 1:
        return 1
    else:
        return n * fact(n-1)
# print(fact(5))