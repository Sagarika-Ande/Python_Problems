import os
x = os.getdir()
print(x)

# import sys
#
# data = sys.argv
#
# print("dgqqqqg")
# if data[1].lower() == "changepassword":
#     print("got")
#
#     try:
#         user = data[2]
#     except IndexError:
#         print("enter user name in command after change password")
#         sys.exit(0)
#     print(f"changing password for user {data[2]}")