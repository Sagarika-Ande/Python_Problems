
# nested loop :- loop in loop called nested loop

# i = 1
# while i < 11:
#     j = 1
#     while j < 11:
#         product = i*j
#         print(f"{i} * {j} = {i*j}")
#         j += 1
#     print()
#     i += 1

# for i in range(1, 11):
#     for j in range(1, 11):
#         print(f"{i} * {j} = {i*j}")
#     print("\n")

# fruits = ["apple","orange","banana"]
# persons = ["ramesh","suresh","paresh"]
# for fruit in fruits:
#     for person in persons:
#         print(f"1{fruit} to {person}")
#     print("\n")


###### pass, break , continue
####break
# for i in range(1, 11):
#     for j in range(1, 11):
#         print(f"{i} * {j} = {i*j}")
#         if j%5==0:
#             break
#     print()
#     if i%3==0:
#         break

#####continue
# for i in range(1, 11):
#     for j in range(1, 11):
#         if j % 5 == 0:
#             continue # continue must be before iteration. continue after iteration does not work.
#         print(f"{i} * {j} = {i*j}")
#
#     print()
#     if i % 3 == 0:
#         break
#####pass :- pass is a null operation — when it is executed, nothing happens.
# It is useful as a placeholder when a statement is required syntactically,
# but no code needs to be executed

# def function():
#     if i in range(1,100):
#         pass