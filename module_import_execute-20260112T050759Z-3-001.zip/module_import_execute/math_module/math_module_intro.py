import math
x = 5.6
print(round(x))
print(math.ceil(x))
print(math.floor(x))
print()
x = 5.2
print(round(x))
print(math.ceil(x))
print(math.floor(x))
