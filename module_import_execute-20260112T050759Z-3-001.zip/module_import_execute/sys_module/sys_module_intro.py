import sys

data = sys.argv    #  data read by sys.argv is ['.\\sys_module_intro.py', '10', '20', '30']

if data[1].lower() == "changepassword":

    try:
        user = data[2]
    except IndexError:
        print("enter user name in command after change password")
        sys.exit(0)
    print(f"changing password for user {data[2]}")


# ###getsizeof # it shows size in bytes
# data1 = [50, 60]
# print(sys.getsizeof(data1))
#
#
# ### exit
# sys.exit(0)




### practice of cd and cd ../
# PS C:\Users\LIKESH\PycharmProjects\Pycharm Projects> cd module_import_execute
# PS C:\Users\LIKESH\PycharmProjects\Pycharm Projects\module_import_execute> cd random_module
# PS C:\Users\LIKESH\PycharmProjects\Pycharm Projects\module_import_execute\random_module> python .\random_module_intro.py
# [5, 5, 3]
# [4, 7, 13, 11, 1, 7, 12, 11, 6, 10, 7, 12, 3]
# ['8', '8', '$']
# ['F', '@', 'D', 'F']
# ['.\\random_module_intro.py']
# PS C:\Users\LIKESH\PycharmProjects\Pycharm Projects\module_import_execute\random_module>

## live example
# data = input("entered comma separated number")
# total = sum([int(x) for x  in data.split(",")])  # list comprehension
# print(total)

# print(args)
# print("hello")
#
# print(args[1])
# print(args[2])
# print("ggg")

# # numbers = args[1:]
# # print(numbers)
# numbers = [int(d) for d in args[1:]]
# sum_numbers = sum(numbers)
# print(sum_numbers)
### actual execution in terminal
# PS C:\Users\LIKESH\PycharmProjects\Pycharm Projects\module_import_execute\sys_module> python .\sys_module_intro.py 10 20 30
# ['.\\sys_module_intro.py', '10', '20', '30']
# 60
