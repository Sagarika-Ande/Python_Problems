
### important module "datetime"

# from datetime import datetime
# print(datetime.now())
# print(datetime.today())

# from Datatypes.list_introduction import *
# print(sample_list1)

# from Datatypes.list_introduction import types_of_denomination
# print(types_of_denomination)


# from Datatypes import list_introduction
# print(list_introduction.l1)


import datetime

# print(dir(datetime))  #['MAXYEAR', 'MINYEAR', '__builtins__','__cached__','__doc__', '__file__','__loader__','__name__',
# '__package__', '__spec__', 'date', 'datetime', 'datetime_CAPI', 'sys', 'time', 'timedelta', 'timezone', 'tzinfo']

# Commonly used classes in the datetime module are:
# * date Class * time Class * datetime Class * timedelta Class

## now
# date_now = datetime.datetime.now()  # datetime(module).datetime(class).now()(self)
# print(date_now)
# print(type(date_now))
# print(date_now.date())
# print(date_now.time())
# print(date_now.day)
# print(date_now.month)
# print(date_now.year)
# print(date_now.hour)
# print(date_now.minute)
# print(date_now.second)
# print(datetime.datetime.now().date())

# back_dated = datetime.datetime(2021, 7, 26, 6, 1, 8, 000)  # positional parameters
# print(back_dated)
# back_date = datetime.datetime(month=4, day=14, year=1995, hour=8, minute=15, second=10)  # keyword parameter
# print(back_date)
# print(back_dated.date())
# print(back_dated.year)
# print(back_dated.month)
# print(back_dated.day)
# print(back_dated.hour)
# print(back_dated.minute)
# print(back_dated.second)


# timestamp :- A timestamp is a sequence of characters or encoded information identifying when a certain event occurred,
# usually giving date and time of day, sometimes accurate to a small fraction of a second.
# Epoch & Unix Timestamp Conversion Tools.

# to timestamp
# date_now_ts = date_now.timestamp()
# back_date_ts = back_date.timestamp()
# print(date_now_ts)
# print(back_date_ts)
# print(datetime.datetime.now().timestamp())
# print()

# from timestamp
# ts = 1646050882  # timestamp copied from Epoch & Unix Timestamp Conversion Tools.
# from_date_time_ts = datetime.datetime.fromtimestamp(ts)
# print(from_date_time_ts)
# print(from_date_time_ts.date())
# print(from_date_time_ts.time())
# print(from_date_time_ts.timestamp())
# print(from_date_time_ts.month)
# print(from_date_time_ts.hour)

#### error itn datetime  ( self(object) and class error.

# print(datetime.datetime.date())  # object is needed to call date(like now etc. here we called date on class(datetime)
# TypeError: descriptor 'date' of 'datetime.datetime' object needs an argument

# strftime   # used to convert type of datetime into string.
# strptime

####  strftime :- datetime object convert to date string (which goes to other API).

# format = ("%a    %Y-%m-%d   %A   %B  %j   %x   %X  %H:%M:%S %p")
# dt_now = datetime.datetime.now()
# str_dt_now = dt_now.strftime(format)
# print(str_dt_now)
# print(type(str_dt_now))
# print()

format = ("%a%Y-%m-%d%A  %H:%M:%S %p")

# ### strptime :date string(which comes from other API)convert to datetime object.
# str_dt_object = "Mon2022-02-28Monday 19:26:10 PM"
# dt_convrt_object = datetime.datetime.strptime(str_dt_object, format)
# print(dt_convrt_object)
# print(dt_convrt_object.date())
# print(dt_convrt_object.time())
# print(type(dt_convrt_object))

# datetime format :-https://www.programiz.com/python-programming/datetime/strptime

### combine :- date and time are combined in datetime.

# dt__now = datetime.datetime.now()
# print(dt__now)
# dt_date = dt__now.date()
# print(dt_date)
# dt_time = dt__now.time()
# print(dt_time)
#
# combined_date_time = datetime.datetime.combine(dt_date, dt_time)
# print(combined_date_time)
# print()


### replace :- replace function will be used with object(complete)


# r1 = dt__now.replace(year=2012,month=12,day=5,hour=12,minute=30)
# print(r1)
# r2 = dt_time.replace(12,35,14)
# print(r2)
# r3 = dt_date.replace(2014,7,14)
# print(r3)
# r4 = combined_date_time.replace(1989,7,26,6,1,8)
# print(r4)
# print()
#
# print(dt_date.weekday())  #mon = 0, tue = 1 etc.
# print(dt_date.isoweekday())  # sun = 0, mon = 1
# print(dt__now.)



dt =time













