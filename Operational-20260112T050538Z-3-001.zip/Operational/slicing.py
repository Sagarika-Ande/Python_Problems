
# Slicing: (used for list, string, tuple)
# slice () functions return a slice object which we can use to slice a sequence type like list, tuple, string, etc.
# Parameters for slicing: applicable for both slice () and name_of_seq [:]
# start (optional) - Starting integer where the slicing of the object starts. Default to None.
# • stop – (optional) - Integer until which the slicing takes place. The slicing stops at index stop-1.
# • step (optional) - Integer value which determines the increment between each index for slicing. Defaults to None.
# ◦ positive value for step: slicing will move in forward direction
# ◦ negative value for step: slicing will move in backward direction.

# sizes = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048]
# sizes.append(4096)
# print("sizes = ",sizes)
sizes = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096]
#index   0  1  2  3  4   5   6    7    8    9    10    11    12
# print(sizes)
# print(type(sizes))
# print(sizes[:])
# print(sizes[::])
# sliced_data = sizes[::]
# print(sliced_data)
# print(sizes[1:]) #[2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096]
# print(sizes[1:1]) # []
# print(sizes[1:2]) # [2]
# print(sizes[1:6]) # [2, 4, 8, 16, 32]
# print(sizes[1:9]) # [2, 4, 8, 16, 32, 64, 128, 256]
# print(sizes[0:16]) # [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096] end out of index valid
# print(sizes[1:4:2]) # [2, 8]
# print(sizes[1:8:3]) # [2, 16, 128]
# print(sizes[1::5]) # [2, 64, 2048]
# print(sizes[:4:2]) # [1, 4]
# print(sizes[::2]) # [1, 4, 16, 64, 256, 1024, 4096]
# print(sizes[::4]) # [1, 16, 256, 4096]
# print(sizes[1::3]) # [2, 16, 128, 1024]

# (-)==negative index slicing
# print(sizes[::-1]) #  special case :- all number reversed
# print(sizes[-2:-10:-1]) # [2048, 1024, 512, 256, 128, 64, 32, 16]
# print(sizes[-1::-2]) # [4096, 1024, 256, 64, 16, 4, 1]
# print(sizes[:-20:-1]) # [4096, 2048, 1024, 512, 256, 128, 64, 32, 16, 8, 4, 2, 1]
# print(sizes[-4:-12:]) # [] need to give negative step in back to forward access.
# print(sizes[-1::-1]) # [4096, 2048, 1024, 512, 256, 128, 64, 32, 16, 8, 4, 2, 1]
# print(sizes[-1:-1:-1]) # []

# # exception
# print(sizes[4:9:-1]) # [] forward direction but negative step
# print(sizes[-4:-8:]) # [] backward direction but positive step


# for string
# s ="r"
# print(s[:])

# error
# print(sizes[55:]) # []
# print(sizes[55]) #IndexError: list index out of range

# another method to define "slice".
# slice_object = slice(2, 7, 1)
# print(sizes[slice_object])   # [4, 8, 16, 32, 64]

# x =[ "g", "r","y",1,4,9,0]
xx = "my name is piyush"
y = xx[8:4:1]
print(y)

#### DRY  concept :- Don't repeat yourself

sizes = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096]
currency = [1, 2, 5, 10, 20, 50, 100, 200, 500]
months = ["jan", "feb", "march", "april", "may", "june"]
weekdays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
slice_data = slice(1, 5, 1)   # In DRY concept we can change slice(1,5,1) to slice(2,6,1)...it can easily makes changes.
print(sizes[slice_data])
print(currency[slice_data])
print(months[slice_data])
print(weekdays[slice_data])
