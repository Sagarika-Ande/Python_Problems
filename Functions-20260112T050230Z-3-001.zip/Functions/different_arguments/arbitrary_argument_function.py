
def any_string(name):
    if name.isdigit():
        return False
    return name.upper()
# print(any_string("amitabh"))
# print(any_string("amir"))
# print(any_string("amit"))
# print(any_string("amay"))

# using arbitrary function  ### difference in (isalpha, isdigit, isdecimal)....
def user_string(*args):
    uppered_list = []
    for data in args:
        if data.isalpha():
            uppered_list.append(data.upper())
    return uppered_list

# print(user_string("amitabh","amir","akshay","ashish"))
# print(user_string("karan","6895","5668","2345"))

def any_function(*args,**kwargs):
    print(type(args))   # args type is tuple......it refer to positional arguments
    print(type(kwargs)) # kwargs type is dict.....it refer to keywords arguments
    print(args) # *args took positional arguments
    print(kwargs) # **kwargs took keywords

    # print(f"{kwargs.keys()}->{kwargs.values()}")
    for keys,values in kwargs.items():  # for loop used in multiple data given
        print(f"{keys.title()}->{values}")

# any_function ( 1, 2, 3,sum = 23, avg = 12 )


def diff_arguments(a,b,c,d,de=10,*f,**g):
    print(a)
    print(b)
    print(c)
    print(d)
    print(de)
    print(f)
    print(g)
diff_arguments(5,6,7,8,11,22,33,44,55,66,avg=20,sum=30,sub=5)
print()
diff_arguments(5,6,7,8,avg=20,sum=30,sub=5)