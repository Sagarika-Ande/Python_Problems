'''
Functions:
One of the most important and frequently used concepts in programming.
Functions are the block of organized code implemented to perform a single related action.
Functions can be reused whenever required.
Functions can accept parameter and return some value.
“return” keyword to return a value from function.
There are two types of function:
• Inbuilt Functions
• User defined Functions
Inbuilt function:
These functions are inbuilt in the programming language and performs a particular operation.
We cannot edit these functions, we can only use them whenever required.
Eg:
• type()
• print()
• len()
'''
#
#
# list1 = [1, 2, 3, 5, 6]
# dict1 = {1:2,3:4}
# print(dir(list1))
# print()
# print(dir(dict1))

# import requests
#
# response = requests.get("https://www.jetbrains.com/help/pycharm/installing-uninstalling-and-upgrading-packages.html")
# # print(response.text)
# print(dir(response))
# print(help(dict1))

##divmod
# print(divmod(22,3))
#
# def my_div_mod(dividend,divisor):
#     quo = dividend//divisor
#     remain = dividend%divisor
#     return quo , remain
# print(my_div_mod(22,3))
#
# frozen_set = frozenset([1,2,3,4])
# print(frozen_set)

## range :-It returns a sequence of numbers and is immutable (whose value is fixed).
# The range function takes one or at most three arguments, namely the start and a stop value along with a step size.
# x = list(range(0, 20, 2))
# print(x)
# y= list(range(0,20))
# print(y)

# for i in range(0, 10):
#     print("@@@@@@@")

# for i in range(1,11):
#     print("@"*i)

#absolute(abs)
# num= abs(-12)
# print(num)

#binary(bin), hex , oct
# x=bin(12)
# print(x)
# y=hex(10)
# z=oct(10)
# print(y)
# print(z)

# #bool
# print("bool on int")
# print(bool(54554))
# print(bool(0))
#
#
# print("bool on string")
# print(bool("enter the code"))
# print(bool(""))
# print(bool(" "))
#
#
# print("bool on list")
# print(bool([2,3,4,5]))
# print(bool([]))

# list=[]
# if not list:  # not + datatypes = True
#     print(list)

########  callable


####### chr-- character  and ord-- ordinance from ASCII chart
# print(chr(99))
# print(ord("c"))


######## enumerate  only sequencial data can be access
#
# data = (2, 3, 6, 8, "good", "receive", "talk", {4, 7})
# d = tuple(enumerate(data, 0))
# print(d)
#
#
# for i,item in enumerate(data,0):
#     print(f"{item} present in {i}")

######## eval  :- used to evaluate the string
# print(eval("3*5+4"))

######### hash and id
# print(hash("s"))
# print(id("s"))

######### input
#
# x = input(45)
# print(x)

######## max and min
# print(max([2,56,789,4,56,3456,234]))
# print(min([34,67,87,2,4,9,567,45]))

######### power
# print(pow(2,5))
# print(2**5)

###### round-of
# print(round(5.436))
# print(round(5.5))
# print(round(5.6))

# data1 =[34,67,87,2,4,9,567,45]
# data1.sort()   #  sort change data permenantly
# print(data1)
# print(sorted(data1)) # retain original data

####### sum
# print(sum([1,24,5,78]))


########### search google for more built in operators