def get_values(age,height,weight,gender,allergy,covid=False,omicron=False):
    print("age =",age)
    print("height =",height)
    print("weight =",weight)
    print("gender =",gender)
    print("allergy =",allergy)
    print("covid =",covid)
    print("omicron =",omicron)
# get_values(age=32,height=5.8,gender="M",weight=59,allergy="sugar")
print()
# get_values(height=5.6,age=34,weight=51,allergy="apendx",gender="M",covid="severe",omicron="none")


def principle_amount(principle,rate=6.5):
    intrest = (principle/100)*rate
    return intrest

print(principle_amount(1000))
print(principle_amount(100,10))

def principle_amount(principle,duration=1,rate=6.5):
    return ((principle/100)*rate)* duration

# print(principle_amount(1000))
# print(principle_amount(100,5,5.5))