#
# '''
# String:
# keyword: str for a Unicode string “hello”
# bytes for a bytestring b” hello”
# in python 2: it was “hello” for bytes
# u” hello” for unicode
# can perform only addition operation, all comparisons operations and
# there are several other methods which we will discuss later.
# '''
# # programiz
# wednesday :- 49 to 80 bytes space required to store and save some exrta information
# dot(.) used to call different operation

s1 = "good"
s2 = "morning"
s3 = "good morning friend"

# accesing string using index

print("character of index 0 and position 1 ", s1[0])
print("character of index 3 and position 4 ", s2[3])

# concatinating two string

print("concatinating srings=", s1+s2 )

# capitalized : capitalized first word of string

print("capitalized the output=",s1.capitalize())
print("capitalized the output=",s2.capitalize())
print("capitalized the output=",s3.capitalize())

# upper :-capitalized whole  string

print("uppered the output=",s1.upper())
print("uppered the output=",s2.upper())
print("uppered the output=",s3.upper())


# title : capitalised first letter of each word of the string

print("titled the output=",s1.title())
print("titled the output=",s2.title())
print("titled the output=",s3.title())


# length of string

print("length of s1=", len(s1))
print("length of s2=", len(s2))
print("length of s3=", len(s3))

# startswith and endswith

print("s1 startswith g =", s1.startswith('g'))
print("s2 startswith m =", s2.startswith('m'))
print("s3 startswith end =", s3.startswith('end'))
print("s2 endswith ing =", s2.endswith('ing'))

# replace


s4 = "26-1-2022"
print("(replace - in s4 by /) =",s4.replace("-","/"))
               # old(-)         new(/)


s5 = "22222272665255256"

print("(replace 2 in s5 by 4) =",s5.replace("2","4"))


# split

print(s3.split())
print(s4.split())
print(s4.split("-"))


# join

any = "string_imp.py"
s = any. split(".")
print(s)

print(" ".join(s))
print(".".join(s))


# var = https://www.programiz.com/python-programming


variable = "https://beginnersbook.com/2019/03/python-keywords-and-identifiers"
print(variable.split("/"))
print("".join(variable))


# isalpha, isalnum, isnumeric

print("kashi".isalnum())    # true
print("23".isalpha())       # false
print("kashi1999gmail.com".isnumeric())   # false
print("rashi".isalpha())      # true


# count

w = "i scream u scream all scream for ice cream"
print("value = ", w.count("cream"))
print("value = ", w.count("scream"))
print("value = ", w.count(" "))

print(w.replace("scream", "cream"))

x = w.replace("scream", "cream")

print(x.count("cream"))
print(x.split("cream"))